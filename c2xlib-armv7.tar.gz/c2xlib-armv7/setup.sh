cp libc2x*.so /usr/local/lib/
cp c2x*.h /usr/local/include/
gcc -Wall test-exec.c -o test-exec.a -lc2xcam
./test-exec.a
ret=$?
if [ $ret = 1 ]
then
  echo "Install c2xlib: OK"
else
  echo "Install c2xlib: FAILED"
fi
