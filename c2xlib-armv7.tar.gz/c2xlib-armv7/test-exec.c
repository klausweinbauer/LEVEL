#include <c2xcam.h>
#include <stdio.h>

int main(int argc, char** argv) {
    return createCAM(1);
}
